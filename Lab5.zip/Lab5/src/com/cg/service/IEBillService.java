package com.cg.service;

import com.cg.dto.BillDTO;
import com.cg.exception.BillUserException;

public interface IEBillService {

	public String insert(BillDTO billDTO) throws BillUserException;
}
