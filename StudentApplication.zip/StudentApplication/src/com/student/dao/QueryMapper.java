package com.student.dao;

public interface QueryMapper {

	public static final String viewAll="SELECT studentroll,studentname,dob FROM student_tbl";
}
