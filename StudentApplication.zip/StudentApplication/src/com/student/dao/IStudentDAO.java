package com.student.dao;

import java.util.List;

import com.student.bean.StudentBean;
import com.student.exception.StudentException;

public interface IStudentDAO {

	List<StudentBean> viewAllStudentDetails() throws StudentException;
}
