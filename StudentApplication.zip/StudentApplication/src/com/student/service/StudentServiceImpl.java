package com.student.service;

import java.util.List;

import com.student.bean.StudentBean;
import com.student.dao.IStudentDAO;
import com.student.dao.StudentDAOImpl;
import com.student.exception.StudentException;

public class StudentServiceImpl implements IStudentService {
private IStudentDAO studentDAO=new StudentDAOImpl();
	@Override
	public List<StudentBean> viewAllStudentDetails() throws StudentException {
		
		return studentDAO.viewAllStudentDetails();
	}

}
