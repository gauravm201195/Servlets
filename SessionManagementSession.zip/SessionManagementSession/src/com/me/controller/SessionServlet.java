package com.me.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class SessionServlet
 */
public class SessionServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public SessionServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();

		List<String> items = null;

		HttpSession session = request.getSession();
		/*
		 * Date date = new Date(session.getCreationTime());
		 * System.out.println(date);
		 */
		items = (List<String>) session.getAttribute("items");

		if (items == null) {
			items = new ArrayList<String>();
			session.setAttribute("items", items);
			/*
			 * date = new Date(session.getLastAccessedTime());
			 * System.out.println("Session accessed: "+date);
			 */
		}
		items.add(request.getParameter("item"));
		// date = new Date(session.getLastAccessedTime());
		// System.out.println("Added in list: " + date);
		out.print("<ul>");
		for (String item : items) {
			out.print("<li>" + item + "</li>");
		}
		out.print("</ul>");
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
	}
}