package com.cg.modulescoremanagement.service;

import java.util.ArrayList;
import java.util.List;

import com.cg.modulescoremanagement.dao.IModuleManagement;
import com.cg.modulescoremanagement.dao.ModuleManagementDao;
import com.cg.modulescoremanagement.dto.AssesmentScore;
import com.cg.modulescoremanagement.dto.Trainees;
import com.cg.modulescoremanagement.exception.ModuleException;

public class ModuleManagementServiceimpl implements IModuleManagementService
{
	IModuleManagement moduledao=null;
	public ModuleManagementServiceimpl() 
	{
		moduledao= new ModuleManagementDao();
	}

	@Override
	public ArrayList<Trainees> getTrainee() throws ModuleException {
		//calling gettrainnee fucntion of dao class
		return moduledao.getTrainee();
	}

	@Override
	public AssesmentScore addScore(AssesmentScore obj) throws ModuleException {
		//calling addScore fucntion of dao class
		return moduledao.addScore(obj);
	}

}
