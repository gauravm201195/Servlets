package com.cg.modulescoremanagement.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.modulescoremanagement.dto.AssesmentScore;
import com.cg.modulescoremanagement.dto.Trainees;
import com.cg.modulescoremanagement.exception.ModuleException;
import com.cg.modulescoremanagement.service.IModuleManagementService;
import com.cg.modulescoremanagement.service.ModuleManagementServiceimpl;


@WebServlet("/ModuleController")
public class ModuleController extends HttpServlet 
{	//creating service class interface refrence variable
	IModuleManagementService serviceobj =null; 
	
    public ModuleController() 
    {
    	
     serviceobj = new ModuleManagementServiceimpl();
        
    }

	
	public void init(ServletConfig config) throws ServletException 
	{
		
	}

	
	public void destroy() 
	{
		
	}

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		//calling dopost method
		doPost(request, response);
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		RequestDispatcher rd=null;
		
		String action=request.getParameter("action");
		try 
	{
		//checking the value of action and performing opertaions accordingly
		if(action!=null)
		{
			//fetching the list of trainee from the database
			if(action.equals("addassessment"))
			{
				
				ArrayList<Trainees> list = serviceobj.getTrainee();
				request.setAttribute("objlist", list);
				rd=request.getRequestDispatcher("AddAssessment.jsp");
				rd.forward(request, response);
				
			}
			//inserting values into assessmentscore table 
			if(action.equals("sendvalues"))
			{
				int id =Integer.parseInt(request.getParameter("id"));
				String mname = request.getParameter("modulename");
				int mpt =Integer.parseInt(request.getParameter("mpt"));
				int mtt =Integer.parseInt(request.getParameter("mtt"));
				int assignment =Integer.parseInt(request.getParameter("assignment"));
				System.out.println(mtt);
				int total=(mpt+mtt+assignment);
				int grade = 0;
				if(total<50)
				{
					grade=0;
				}
				else if(total>49&&total<59)
				{
					grade=1;
				}
				else if(total>59&&total<69)
				{
					grade=2;
				}
				else if(total>69&&total<79)
				{
					grade=3;
				}
				else if(total>79&&total<89)
				{
					grade=4;
				}
				else if(total>89&&total<101)
				{
					grade=5;
				}
				AssesmentScore obj= new AssesmentScore(id,mname,mpt,mtt,assignment,total,grade);
				AssesmentScore obj1 = null;
				obj1 =serviceobj.addScore(obj);
				
				//displaying the module score in new jsp page
				request.setAttribute("obj1", obj1);
				rd=request.getRequestDispatcher("ModuleScore.jsp");
				rd.forward(request, response);
				
			}
		}
	}
		 catch (ModuleException e) 
		 {
				
			 rd=request.getRequestDispatcher("EmpErrors.jsp");
				rd.forward(request, response);
				
				
		 }
		
	}

}
